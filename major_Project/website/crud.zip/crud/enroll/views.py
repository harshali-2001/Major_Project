from django.shortcuts import render
import pyart
import os
import xlwt
from xlwt import Workbook
import numpy as np
import pandas as pd
from scipy import stats as st
import statistics as st
from statistics import mode, StatisticsError



# Create your views here.
# def home(request):
# 	return HttpResponse('Hello world!')

def home(request):
    file_name = request.POST.get('Path')
    dir_list= os.listdir(file_name)
    #print(dir_list)
    if file_name is None:
        print("error")
    else:
        print('start')
        emp_dir = "C:\\Users\\alxgr\\Downloads\\excel"
        isFile= os.path.isdir(emp_dir)
        if (isFile == False):
            os.mkdir(emp_dir)
            # Writing to an excel
            # sheet using Python
            # Workbook is created
        wb = Workbook()

            # add_sheet is used to create sheet.
        sheet1 = wb.add_sheet('Sheet 1')
        sheet1.write(0, 0, 'TIME')
        sheet1.write(0, 1, 'NAME')
        sheet1.write(0, 2, 'REFLECTIVITY')
        sheet1.write(0, 3, 'VELOCITY')
        sheet1.write(0, 4, 'POWER')
        sheet1.write(0, 5, 'SPECTRUM_WIDTH')

        k = 1
        for i in dir_list:
            radar = pyart.io.read(file_name + "\\"+i)
            raw = radar.fields

             # for time
            time = pyart.util.datetime_from_radar(radar)
            time = str(time)
            time = time.split(" ")
            time = time[-1]

            # for reflectivity
            y = raw.get('reflectivity')
            z = y.get('data')
            reflectivity_array = np.array(z)
            filter_arr = np.logical_and(np.greater(reflectivity_array, 30), np.less(reflectivity_array, 80))
            try:
                r = st.mode(reflectivity_array[filter_arr])
            except StatisticsError:
                r = None
            del reflectivity_array
            del filter_arr
             #  for velocity
            a = raw.get('velocity')
            b = a.get('data')
            velocity_array = np.array(b)
            filter_arr = np.logical_and(np.greater(velocity_array, -30), np.less(velocity_array, 30))
            try:
                v = st.mode(velocity_array[filter_arr])
            except StatisticsError:
                v = None
            del velocity_array
            del filter_arr

            #  for total_pow
            c = raw.get('total_power')
            d = c.get('data')
            total_power_array = np.array(d)
            filter_arr = np.logical_and(np.greater(total_power_array, 0), np.less(total_power_array, 80))
            try:
                p = st.mode(total_power_array[filter_arr])
            except StatisticsError:
                p = None
            del total_power_array
            del filter_arr

            #  for spectrum_width
            e = raw.get('spectrum_width')
            f = a.get('data')
            spectrum_width_array = np.array(f)
            filter_arr = np.logical_and(np.greater(spectrum_width_array, 0), np.less(spectrum_width_array, 30))
            try:
                s = st.mode(spectrum_width_array[filter_arr])
            except StatisticsError:
                s = None
            del spectrum_width_array
            del filter_arr
            if (r != None and v != None and s != None and p != None):
                sheet1.write(k, 0, time)
                sheet1.write(k, 1, i)
                sheet1.write(k, 2, str(r))
                sheet1.write(k, 3, str(v))
                sheet1.write(k, 4, str(p))
                sheet1.write(k, 5, str(s))
                k = k + 1
                print(k)

        print("DONE!")
        wb.save('xlwt example2.xls')
    return render(request , 'Home.html')

